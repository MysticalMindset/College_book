/*******************************************************************************
 * pwm.c — Hardware PWM on PB6 (M0PWM0, 25 kHz)
 *
 * PWM Module 0, Generator 0, Output A (M0PWM0) drives PB6.
 * The system clock (16 MHz) feeds the PWM counter directly (USEPWMDIV = 0).
 *   Period  = 16 000 000 / 25 000 = 640 counts  →  LOAD = 639
 *   Smaller CMPA value → longer HIGH time → higher duty cycle
 *
 * Port B clock is already on when this init runs (I2C0 init enables it).
 ******************************************************************************/

#include "config.h"
#include "delay.h"
#include "pwm.h"

/* ---- PWM0 module registers (raw; avoids relying on CMSIS PWM struct) ---- */
#define SYSCTL_RCGCPWM_R  (*((volatile uint32_t *)0x400FE640u))
#define SYSCTL_RCC_R      (*((volatile uint32_t *)0x400FE060u))

#define PWM0_ENABLE_R     (*((volatile uint32_t *)0x40028008u))
#define PWM0_0_CTL_R      (*((volatile uint32_t *)0x40028040u))
#define PWM0_0_GENA_R     (*((volatile uint32_t *)0x40028060u))
#define PWM0_0_LOAD_R     (*((volatile uint32_t *)0x40028050u))
#define PWM0_0_CMPA_R     (*((volatile uint32_t *)0x40028058u))

#define SYSCLK_HZ         16000000u
#define PWM_FREQ_HZ       25000u
#define PWM_TOP           ((SYSCLK_HZ / PWM_FREQ_HZ) - 1u)   /* 639 */

/* ========================================================================== */

void PWM0_Init(void)
{
    /* 1) Enable PWM0 module clock; clear USEPWMDIV so PWM runs at sysclk */
    SYSCTL_RCGCPWM_R |= (1u << 0);
    SYSCTL_RCC_R     &= ~(1u << 20);   /* USEPWMDIV = 0 */
    delayMs(1);                         /* let clock settle */

    /* 2) PB6 → M0PWM0 alternate function */
    GPIOB->AFSEL |=  (1u << 6);
    GPIOB->DEN   |=  (1u << 6);
    GPIOB->AMSEL &= ~(1u << 6);
    GPIOB->DIR   |=  (1u << 6);
    GPIOB->PCTL  =  (GPIOB->PCTL & ~(0xFu << 24)) | (0x4u << 24);

    /* 3) Configure Generator 0 */
    PWM0_0_CTL_R  = 0;                 /* disable during setup */
    PWM0_0_GENA_R = 0x0000008Cu;       /* HIGH on LOAD, LOW on CMPA match */
    PWM0_0_LOAD_R = PWM_TOP;           /* 25 kHz period */
    PWM0_0_CMPA_R = PWM_TOP;           /* start at 0 % (compare == LOAD) */

    /* 4) Start the generator; output stays gated off until duty > 0 */
    PWM0_0_CTL_R |= 0x1u;
}

/* -------------------------------------------------------------------------- */

void PWM0_SetDuty(float pct)
{
    uint32_t cmp;

    if (pct <= 0.0f)
    {
        PWM0_ENABLE_R &= ~0x1u;        /* gate output off → PB6 stays low */
        return;
    }
    if (pct > 100.0f) pct = 100.0f;

    PWM0_ENABLE_R |= 0x1u;            /* (re-)enable output */

    /* Map duty to compare value.
       At cmp = 0 the pin is HIGH for the full period (100 %).
       At cmp = PWM_TOP the pin goes LOW almost immediately (≈ 0 %). */
    if (pct >= 100.0f)
    {
        cmp = 0u;
    }
    else
    {
        cmp = ((PWM_TOP + 1u) * (uint32_t)(100.0f - pct + 0.5f)) / 100u;
    }
    PWM0_0_CMPA_R = cmp;
}

/* -------------------------------------------------------------------------- */

void PWM0_KickStart(void)
{
    /* Blast 100 % for 500 ms to overcome motor stiction.
       Caller (main) will call PWM0_SetDuty(duty) immediately after. */
    PWM0_SetDuty(100.0f);
    delayMs(500);
}
