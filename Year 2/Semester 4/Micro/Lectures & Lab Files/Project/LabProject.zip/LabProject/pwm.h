/*******************************************************************************
 * pwm.h — Hardware PWM on PB6 (M0PWM0, 25 kHz)
 ******************************************************************************/

#ifndef PWM_H
#define PWM_H

void PWM0_Init(void);
void PWM0_SetDuty(float pct);   /* 0.0 – 100.0 % ; hardware handles timing */
void PWM0_KickStart(void);      /* 500 ms full-power pulse to overcome inertia */

#endif /* PWM_H */
