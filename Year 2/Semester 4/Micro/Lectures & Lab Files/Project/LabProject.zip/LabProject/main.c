/*******************************************************************************
 * main.c — PID Fan Controller — TM4C123GH6PM
 *
 * ============================================================================
 *  WIRING
 * ============================================================================
 *
 *  COMPONENT                | WIRE/PIN     | LAUNCHPAD PIN
 *  -------------------------|--------------|-------------------------------
 *  LCD (I2C addr 0x28)      | SCL          | PB2  (I2C0 SCL)
 *                           | SDA          | PB3  (I2C0 SDA)
 *                           | VCC          | 5V (Vss)
 *                           | GND          | GND
 *                           |              |
 *  DS18B20 Probe            | Red (VCC)    | 3.3V
 *                           | Black (GND)  | GND
 *                           | Yellow (DATA)| PE1 + 5k resistor to 3.3V
 *                           |              |
 *  Potentiometer (10k)      | One end      | GND
 *  (setpoint dial)          | Wiper (mid)  | PE3  (AIN0)
 *                           | Other end    | 3.3V
 *                           |              |
 *  4-Wire PC Fan            | Black        | External 12V PSU GND
 *                           | Red/Yellow   | External 12V PSU +12V
 *                           | Blue (PWM)   | PB6  (M0PWM0, 25 kHz hardware PWM)
 *                           | Green (tach) | not connected
 *                           |              |
 *  Heartbeat LED            | (onboard)    | PF1  (red LED)
 *
 * ============================================================================
 *  BUILD: Keil uVision with CMSIS TM4C123GH6PM device pack
 * ============================================================================
 */

#include "config.h"
#include "delay.h"
#include "lcd.h"
#include "ds18b20.h"
#include "adc.h"
#include "pwm.h"
#include "pid.h"

/* ====================================================================== */
/*  GPIO — PF1 red LED heartbeat                                           */
/* ====================================================================== */

static void PortF_Init(void)
{
    SYSCTL->RCGCGPIO |= 0x20u;
    while ((SYSCTL->PRGPIO & 0x20u) == 0) {}
    GPIOF->DIR |=  0x02u;
    GPIOF->DEN |=  0x02u;
}

/* ====================================================================== */
/*  Startup diagnostic: print raw scratchpad bytes on LCD                  */
/* ====================================================================== */

static void ShowScratchpadDiag(void)
{
    uint8_t sp[9];
    char    hex[4];
    int     i;

    OW_Reset();
    OW_WriteByte(OW_CMD_SKIP_ROM);
    OW_WriteByte(OW_CMD_READ_SCRATCH);
    for (i = 0; i < 9; i++)
        sp[i] = OW_ReadByte();
    OW_Reset();

    LCD_Clear();
    LCD_SetCursor(0x00);
    LCD_Print("Raw:");
    for (i = 0; i < 4; i++)
    {
        hex[0] = "0123456789ABCDEF"[sp[i] >> 4];
        hex[1] = "0123456789ABCDEF"[sp[i] & 0x0F];
        hex[2] = ' ';
        hex[3] = '\0';
        LCD_Print(hex);
    }
    LCD_SetCursor(0x40);
    for (i = 4; i < 9; i++)
    {
        hex[0] = "0123456789ABCDEF"[sp[i] >> 4];
        hex[1] = "0123456789ABCDEF"[sp[i] & 0x0F];
        hex[2] = ' ';
        hex[3] = '\0';
        LCD_Print(hex);
    }
    delayMs(4000);
}

/* ====================================================================== */
/*  main                                                                    */
/* ====================================================================== */

int main(void)
{
    float   curTempC = 0.0f;
    float   setTempC = 0.0f;
    float   duty     = 0.0f;
    uint32_t adcPot;
    uint8_t  sensorOk = 0;
    uint8_t  retries;

    /* ---- Peripheral init ---- */
    SysTick_Init();
    I2C0_Init_50kHz();
    LCD_Init();
    OW_Init();
    ADC0_Init();
    PWM0_Init();
    PortF_Init();

    /* ---- Splash screen ---- */
    LCD_SetCursor(0x00);
    LCD_Print("PID Fan Control");
    LCD_SetCursor(0x40);
    LCD_Print("  Starting...   ");
    delayMs(1500);

    /* ---- Probe for DS18B20 with retries ---- */
    for (retries = 0; retries < 5; retries++)
    {
        if (OW_Reset())
        {
            sensorOk = 1;
            break;
        }
        delayMs(200);
    }

    if (sensorOk)
    {
        LCD_Clear();
        LCD_Print("Sensor found!");
        LCD_SetCursor(0x40);
        LCD_Print("Converting...");

        DS18B20_StartConvert();
        ShowScratchpadDiag();
    }
    else
    {
        LCD_Clear();
        LCD_Print("NO SENSOR!");
        LCD_SetCursor(0x40);
        LCD_Print("Check PE1 wire");
        delayMs(3000);
    }

    /* ====================================================================
     *  Main control loop
     * ==================================================================== */
    while (1)
    {
        /* ---- Temperature acquisition ---- */
        if (sensorOk)
        {
            DS18B20_StartConvert();
            curTempC = DS18B20_ReadTemp();

            if (curTempC < -998.5f)         /* -999: no presence pulse */
            {
                sensorOk = OW_Reset();
                duty     = 0.0f;
            }
            else if (curTempC < -997.5f)    /* -998: power-on default, retry */
            {
                duty = 0.0f;
            }
        }
        else
        {
            /* Try to reacquire sensor */
            sensorOk = OW_Reset();
            if (sensorOk)
            {
                DS18B20_StartConvert();
                curTempC = DS18B20_ReadTemp();
            }
            duty = 0.0f;
        }

        /* ---- Setpoint from potentiometer ---- */
        adcPot   = ADC0_ReadPotAvg();
        setTempC = MIN_SET_C + ((float)adcPot / 4095.0f) * (MAX_SET_C - MIN_SET_C);

        /* ---- PID ---- */
        if (sensorOk && curTempC > -900.0f)
            duty = PID_Compute(setTempC, curTempC, 2.0f); /* ~750ms convert + ~1000ms delay + ~80ms LCD */
        else
            duty = 0.0f;

        /* ---- Fan output with kick-start ---- */
        {
            static uint8_t fanWasOff = 1;

            if (duty > 0.0f && fanWasOff)
            {
                PWM0_KickStart();
                fanWasOff = 0;
            }
            else if (duty <= 0.0f)
            {
                fanWasOff = 1;
            }

            PWM0_SetDuty(duty);
        }

        /* ---- LCD update ---- */
        {
            uint8_t status = sensorOk ? 1u : 0u;
            if (sensorOk && curTempC < -997.5f) status = 2u;
            LCD_Update(curTempC, setTempC, duty, status);
        }

        /* ---- Heartbeat LED ---- */
        GPIOF->DATA ^= 0x02u;

        /* ---- Pace the loop to ~2 seconds (hardware PWM runs on its own) ---- */
        delayMs(1000);
    }
}