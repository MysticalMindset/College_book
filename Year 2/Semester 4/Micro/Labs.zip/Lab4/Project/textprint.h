#ifndef TEXTPRINT_H
#define TEXTPRINT_H
void textprint(char *str);
void UART0_Init(void);
void textnumber(unsigned long n);
#endif