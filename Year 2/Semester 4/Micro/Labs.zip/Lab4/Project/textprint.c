#include <stdio.h>
#include "TM4C123GH6PM.h"
#include "delayMs.h"
#include "textprint.h"

void textprint(char *str){
    while (*str){
        while (UART0->FR & 0x20) {}
        UART0->DR = *str++;
    }
}

void UART0_Init(void){
    SYSCTL->RCGCUART |= 0x01;   // enable UART0
    SYSCTL->RCGCGPIO |= 0x01;   // enable Port A
    while((SYSCTL->PRGPIO & 0x01) == 0){}

    UART0->CTL = 0;             // disable UART

    UART0->IBRD = 104;          // 9600 baud
    UART0->FBRD = 11;
    UART0->CC = 0x0;            // system clock
    UART0->LCRH = 0x60;         // 8-bit, no parity, 1 stop

    UART0->CTL = 0x301;         // enable TX, RX

    GPIOA->AFSEL |= 0x03;
    GPIOA->DEN   |= 0x03;
    GPIOA->PCTL  |= 0x11;
    delayMs(100);
}

void UART0_TxChar(char c){
    while((UART0->FR & 0x20) != 0){}
    UART0->DR = c;
}

void textnumber(unsigned long n){
    char buf[20];
    int i = 0;

    if(n == 0){
        UART0_TxChar('0');
        return;
    }

    while(n > 0){
        buf[i++] = (n % 10) + '0';
        n /= 10;
    }

    for(int j = i - 1; j >= 0; j--){
        UART0_TxChar(buf[j]);
    }
}