#include <stdio.h>
#include "TM4C123GH6PM.h"
#include "delayMs.h"
#include "Activity_2.h"
#include "textprint.h"

static void waitSystick(unsigned long delay);

void Activity2(void){
    /* Enable clock for Port F */
    SYSCTL->RCGCGPIO |= 0x20;
    while((SYSCTL->PRGPIO & 0x20) == 0){}   // wait until Port F is ready

    /* Set PF2 as output (blue LED) */
    GPIOF->DIR |= 0x04;
    GPIOF->DEN |= 0x04;

    /* SysTick setup */
    SysTick->CTRL = 0;           // disable SysTick during setup
    SysTick->CTRL = 0x05;        // enable SysTick, use system clock, no interrupt

    textprint("Activity 2: Ongoing\r\n");
    delayMs(100);
/*
    for(int i = 0; i < 3; i++){
        GPIOF->DATA ^= 0x04;
        waitSystick(1000);
        GPIOF->DATA ^= 0x04;
        waitSystick(1000);
    }
*/
    
    //Infinity
    while(1){
        GPIOF->DATA ^= 0x04;     // toggle blue LED
        waitSystick(2);
    }
    
    
    textprint("Activity 2: Complete\r\n");
    delayMs(100);
}

void waitSystick(unsigned long delay){
    unsigned long i;
    for(i = 0; i < delay; i++){
        SysTick->LOAD = 15999999;     // 1 second (16 MHz)
        SysTick->VAL = 0;
        while((SysTick->CTRL & 0x10000) == 0){}
    }
}