#include <stdio.h>
#include "TM4C123GH6PM.h"
#include "delayMs.h"
#include "Activity_3.h"
#include "textprint.h"

static void PortF_ButtonInit(void);
static void SysTick_FreeRunInit(void);
static void WaitForSW1Press(void);
static void WaitForSW1Release(void);
static void WaitForSW2Press(void);
static void WaitForSW2Release(void);

volatile unsigned long systick_overflows = 0;

void SysTick_Handler(void){
    systick_overflows++;
}

void Activity3(void){
    unsigned long firstTime, secondTime;
    unsigned long firstOverflow, secondOverflow;
    unsigned long tickDiff;
    unsigned long time_us;

    PortF_ButtonInit();
    SysTick_FreeRunInit();

    
    while(1){
        // Wait for first button press on SW1 (PF4)
        textprint("Press SW1 to Start\r\n");
        WaitForSW1Press();
        firstOverflow = systick_overflows;
        firstTime = SysTick->VAL;
        WaitForSW1Release();

        // Wait for first button press on SW1 (PF4)
        textprint("Press SW2 to Stop\r\n");
        WaitForSW2Press();
        secondOverflow = systick_overflows;
        secondTime = SysTick->VAL;
        WaitForSW2Release();

        tickDiff = (secondOverflow - firstOverflow) * (0x00FFFFFF + 1) + (firstTime - secondTime);

        //Convert to microsecons
        time_us = tickDiff / 16;

        //UART
        textprint("Time(us): ");
        textnumber(time_us);
        textprint("\r\n");

        //Display on LCD
    }
}

static void PortF_ButtonInit(void){
    SYSCTL->RCGCGPIO |= 0x20;              // enable Port F clock
    while((SYSCTL->PRGPIO & 0x20) == 0){}  // wait until ready

    GPIOF->LOCK = 0x4C4F434B;              // unlock PF0
    GPIOF->CR |= 0x11;                     // allow changes to PF4 and PF0

    GPIOF->DIR &= ~0x11;                   // PF4, PF0 input
    GPIOF->DEN |= 0x11;                    // digital enable
    GPIOF->PUR |= 0x11;                    // enable pull-up resistors
}

static void SysTick_FreeRunInit(void){
    SysTick->CTRL = 0;               // disable during setup
    SysTick->LOAD = 0x00FFFFFF;      // max 24-bit reload
    SysTick->VAL  = 0;               // clear current value
    SysTick->CTRL = 0x05;            // enable, system clock, no interrupt
}

static void WaitForSW1Press(void){
    while((GPIOF->DATA & 0x10) != 0){}   // wait until PF4 = 0
}

static void WaitForSW1Release(void){
    while((GPIOF->DATA & 0x10) == 0){}   // wait until released
}

static void WaitForSW2Press(void){
    while((GPIOF->DATA & 0x01) != 0){}   // wait until PF0 = 0
}

static void WaitForSW2Release(void){
    while((GPIOF->DATA & 0x01) == 0){}   // wait until released
}