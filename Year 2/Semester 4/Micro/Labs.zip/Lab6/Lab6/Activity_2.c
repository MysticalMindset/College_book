#include <stdio.h>
#include "TM4C123GH6PM.h"
#include "delayMs.h"
#include "Activity_2.h"
#include "u_art.h"

/* ── Main ── */
void Activity2(){
    UART0_Init();
    ADC0_AIN4_Init();

    UART0_SendString("Lab 6 - Activity 2: ADC on AIN4\r\n");
    delayMs(100);
    UART0_SendString("----------------------------------\r\n");
    delayMs(100);

    while (1) {
        unsigned long raw = ADC0_ReadAIN4();
        unsigned long mv  = (raw * 3300UL) / 4095UL;

        UART0_SendString("AIN4 Raw: ");
        delayMs(100);
        UART0_SendUInt(raw);
        delayMs(100);
        UART0_SendString("  |  Voltage: ");
        delayMs(100);
        UART0_SendVoltage_mV(mv);
        delayMs(100);
        UART0_SendString("\r\n");
        delayMs(100);

        volatile int d;
        for (d = 0; d < 800000; d++) {}
    }
}