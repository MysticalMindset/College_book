#include <stdio.h>
#include "TM4C123GH6PM.h"
#include "delayMs.h"
#include "Activity_1.h"
#include "u_art.h"

/* ── Main ── */
void Activity1(){
    UART0_Init();
    ADC0_AIN0_Init();

    UART0_SendString("Lab 6 - Activity 1: ADC on AIN0\r\n");
    delayMs(100);
    UART0_SendString("----------------------------------\r\n");
    delayMs(100);

    while (1) {
        unsigned long raw = ADC0_ReadAIN0();

        /*
         * Voltage formula:
         *   Vout = (ADC_value / 4095) * Vref
         *   Vref = 3.3 V  →  Vout_mV = raw * 3300 / 4095
         */
        unsigned long mv = (raw * 3300UL) / 4095UL;

        UART0_SendString("AIN0 Raw: ");
        delayMs(100);
        UART0_SendUInt(raw);
        delayMs(100);
        UART0_SendString("  |  Voltage: ");
        delayMs(100);
        UART0_SendVoltage_mV(mv);
        delayMs(100);
        UART0_SendString("\r\n");
        delayMs(100);

        /* ~500 ms delay (simple busy-wait) */
        volatile int d;
        for (d = 0; d < 800000; d++) {}
    }
}
