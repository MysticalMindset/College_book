#include <stdio.h>
#include "RTE_Components.h"
#include CMSIS_device_header
#include "delayMs.h"
#include "Activity_1.h"
#include "Activity_2.h"

int main() {
    //Activity1();
    Activity2();
}
