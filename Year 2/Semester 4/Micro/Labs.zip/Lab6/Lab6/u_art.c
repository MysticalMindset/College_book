#include <stdio.h>
#include "delayMs.h"
#include "RTE_Components.h"
#include CMSIS_device_header

void UART0_Init(void) {
    SYSCTL->RCGCUART |= 0x01;
    SYSCTL->RCGCGPIO |= 0x01;
    while ((SYSCTL->PRGPIO & 0x01) == 0) {}

    GPIOA->AFSEL |= 0x03;
    GPIOA->DEN   |= 0x03;
    GPIOA->PCTL  = (GPIOA->PCTL & ~0xFF) | 0x11;

    UART0->CTL  = 0;
    UART0->CC   = 0x5;     // PIOSC = 16 MHz
    UART0->IBRD = 104;     // 9600 baud with 16 MHz
    UART0->FBRD = 11;
    UART0->LCRH = 0x60;    // 8-bit, no parity, 1 stop, no FIFO
    UART0->CTL  = 0x301;   // enable UART, TXE, RXE
    delayMs(100);
}

void UART0_SendChar(char c) {
    while (UART0->FR & 0x20) {}
    UART0->DR = c;
}

void UART0_SendString(const char *s) { while (*s){ UART0_SendChar(*s++); } }

/* Print unsigned 32-bit integer */
void UART0_SendUInt(unsigned long n) {
    char buf[12];
    int  i = 0;
    if (n == 0) { UART0_SendChar('0'); return; }
    while (n > 0) { buf[i++] = (char)('0' + n % 10); n /= 10; }
    while (--i >= 0) UART0_SendChar(buf[i]);
}

/* Print "X.YYY V" from a millivolt value */
void UART0_SendVoltage_mV(unsigned long mv) {
    UART0_SendUInt(mv / 1000);
    UART0_SendChar('.');
    unsigned long frac = mv % 1000;
    /* always print 3 decimal places */
    if (frac < 100) UART0_SendChar('0');
    if (frac < 10)  UART0_SendChar('0');
    UART0_SendUInt(frac);
    UART0_SendString(" V");
}

/* ── ADC0, Sequencer 3, AIN0 (PE3) ── */
void ADC0_AIN0_Init(void) {
    SYSCTL->RCGCADC  |= 0x01;         // enable ADC0 clock
    SYSCTL->RCGCGPIO |= 0x10;         // enable Port E clock
    while ((SYSCTL->PRGPIO & 0x10) == 0) {}

    /* PE3 = AIN0: disable digital, disable alternate function, enable analog */
    GPIOE->DIR   &= ~0x08;
    GPIOE->AFSEL |= 0x08;
    GPIOE->DEN   &= ~0x08;
    GPIOE->AMSEL |=  0x08;

    ADC0->ACTSS  &= ~0x08;            // disable SS3 during config
    ADC0->EMUX   &= ~0xF000;          // SS3 trigger = software (0x0)
    ADC0->SSMUX3  =  0;               // AIN0
    ADC0->SSCTL3  =  0x06;            // IE0 + END0 (single sample, interrupt, end)
    ADC0->IM     &= ~0x08;            // disable SS3 interrupt
    ADC0->ACTSS  |=  0x08;            // enable SS3
}

unsigned long ADC0_ReadAIN0(void) {
    ADC0->PSSI   |=  0x08;            // initiate SS3
    while ((ADC0->RIS & 0x08) == 0) {} // wait for conversion complete
    unsigned long result = ADC0->SSFIFO3 & 0xFFF;
    ADC0->ISC    |=  0x08;            // clear flag
    return result;
}

/* ── ADC0, Sequencer 3, AIN4 (PD3) ── */
void ADC0_AIN4_Init(void) {
    SYSCTL->RCGCADC  |= 0x01;         // enable ADC0 clock
    SYSCTL->RCGCGPIO |= 0x08;         // enable Port D clock  ← changed from 0x10 (Port E)
    while ((SYSCTL->PRGPIO & 0x08) == 0) {}

    /* PD3 = AIN4 */
    GPIOD->DIR   &= ~0x08;
    GPIOD->AFSEL |= 0x08;
    GPIOD->DEN   &= ~0x08;
    GPIOD->AMSEL |=  0x08;

    ADC0->ACTSS  &= ~0x08;
    ADC0->EMUX   &= ~0xF000;
    ADC0->SSMUX3  =  4;               // AIN4  ← changed from 0 (AIN0)
    ADC0->SSCTL3  =  0x06;
    ADC0->IM     &= ~0x08;
    ADC0->ACTSS  |=  0x08;
}

unsigned long ADC0_ReadAIN4(void) {
    ADC0->PSSI   |=  0x08;
    while ((ADC0->RIS & 0x08) == 0) {}
    unsigned long result = ADC0->SSFIFO3 & 0xFFF;
    ADC0->ISC    |=  0x08;
    return result;
}
