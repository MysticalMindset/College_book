#ifndef U_ART_H
#define U_ART_H
void UART0_Init(void);
void UART0_SendChar(char c);
void UART0_SendString(const char *s);
void UART0_SendUInt(unsigned long n);
void UART0_SendVoltage_mV(unsigned long mv);
void ADC0_AIN0_Init(void);
unsigned long ADC0_ReadAIN0(void);
void ADC0_AIN4_Init(void);
unsigned long ADC0_ReadAIN4(void);
#endif