#include <stdio.h>
#include "TM4C123GH6PM.h"
#include "delayMs.h"
#include "Activity3_4.h"

static void UART0_Tx_Char(char c);
static void UART0_Tx_String(char str[]);
static void UART0_Rx_String(char str[], int maxLen);

void Activity34(void){

    char buffer[20];

    SYSCTL->RCGCUART |= 1;   // Enable UART0 clock
    SYSCTL->RCGCGPIO |= 1;   // Enable GPIOA clock

    UART0->CTL = 0;          // Disable UART0 before config

    GPIOA->DEN   |= 0x03;    // PA0, PA1 digital enable
    GPIOA->AFSEL |= 0x03;    // PA0, PA1 alternate function
    GPIOA->PCTL  &= ~0x000000FF;
    GPIOA->PCTL  |=  0x00000011;   // PA0 = U0RX, PA1 = U0TX

    UART0->IBRD = 104;       // 9600 baud for 16 MHz clock
    UART0->FBRD = 11;
    UART0->CC   = 0;       // use PIOSC 16 MHz
    UART0->LCRH = 0x60;      // 8-bit, no parity, 1 stop bit

    UART0->CTL = 0x301;      // Enable UART0, TXE, RXE
    delayMs(100);

    UART0_Tx_String("Activity 3: Ongoing...\r\n");
    UART0_Tx_String("Hello from TM4C123!\r\n");
    UART0_Tx_String("Activity 3: Completed...\r\n");

    UART0_Tx_String("Activity 4: Ongoing...\r\n");
    UART0_Tx_String("Enter a string: ");

    UART0_Rx_String(buffer, 20);

    UART0_Tx_String("\r\nYou typed: ");
    UART0_Tx_String(buffer);
    UART0_Tx_String("\r\n");

    UART0_Tx_String("Activity 4: Completed...\r\n");
    delayMs(100);
}

static void UART0_Tx_Char(char c){
    while(UART0->FR & 0x20);   // Wait if TX FIFO full
    UART0->DR = c;
}

static void UART0_Tx_String(char str[]){
    int i = 0;
    while(str[i] != '\0'){
        UART0_Tx_Char(str[i]);
        i++;
    }
}

static void UART0_Rx_String(char str[], int maxLen){
    int i = 0;
    char c;

    while(1){
        while(UART0->FR & 0x10);   // Wait until RX FIFO not empty
        c = UART0->DR & 0xFF;

        if(c == '\r'){             // Enter pressed
            break;
        }

        if(i < maxLen - 1){        // Prevent buffer overflow
            str[i] = c;
            i++;
            UART0_Tx_Char(c);      // Echo character
        }
    }

    str[i] = '\0';
}