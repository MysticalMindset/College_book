#ifndef ACTIVITY_1_H
#define ACTIVITY_1_H

void Activity1(void);
void Activity1_p2(void);

#endif