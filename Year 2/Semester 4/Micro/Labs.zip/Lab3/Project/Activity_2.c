#include <stdio.h>
#include "TM4C123GH6PM.h"
#include "delayMs.h"
#include "Activity_2.h"

static char UART0Rx(void);
static void UAR(char z);
static void UART0Print(char *str);
static void printMenu(void);

void Activity2(void){
    int doneState = 0;
    char c;

    SYSCTL->RCGCUART |= 1;      /* provide clock to UART0 */
    SYSCTL->RCGCGPIO |= 1;      /* enable clock to PORTA */
    SYSCTL->RCGCGPIO |= 0x20;   /* enable clock to PORTF */
    delayMs(1);

    /* UART0 initialization */
    UART0->CTL = 0;             /* disable UART0 */

    /* UART0 TX0 and RX0 use PA0 and PA1 */
    GPIOA->DEN = 0x03;
    GPIOA->AFSEL = 0x03;
    GPIOA->PCTL = 0x11;

    UART0->IBRD = 104;
    UART0->FBRD = 11;
    UART0->CC = 0;
    UART0->LCRH = 0x60;         /* 8-bit, no parity, 1-stop bit */
    UART0->CTL = 0x301;         /* enable UART0, TXE, RXE */

    /* Port F setup for LEDs PF1, PF2, PF3 */
    GPIOF->DIR |= 0x0E;
    GPIOF->DEN |= 0x0E;
    GPIOF->DATA &= ~0x0E;

    delayMs(100);

    UART0Print("Activity 2: Ongoing\r\n");
    printMenu();

    for(;;){
    c = UART0Rx();                  /* receive character */

    UAR(c);                         /* echo back */

    /* Detect "Done" */
    if(doneState == 0 && c == 'D') doneState = 1;
    else if(doneState == 1 && c == 'o') doneState = 2;
    else if(doneState == 2 && c == 'n') doneState = 3;
    else if(doneState == 3 && c == 'e') break;
    else doneState = 0;

    UART0Print("\r\n");

    switch(c){
        case 'r':
            GPIOF->DATA = 0x02;
            UART0Print("Red LED ON\r\n");
            break;

        case 'g':
            GPIOF->DATA = 0x08;
            UART0Print("Green LED ON\r\n");
            break;

        case 'b':
            GPIOF->DATA = 0x04;
            UART0Print("Blue LED ON\r\n");
            break;

        case 'o':
            GPIOF->DATA = 0x00;
            UART0Print("All LEDs OFF\r\n");
            break;

        case 'h':
            printMenu();
            break;

        case '*':
            UART0Print("Secret message: UART has entered comedy mode.\r\n");
            break;

        default:
            GPIOF->DATA = (c << 1) & 0x0E;
            UART0Print("Invalid command\r\n");
            break;
        }
    }

    UART0Print("\r\nProgram exited after receiving 'Done'\r\n");

}

static char UART0Rx(void){
    while((UART0->FR & 0x10) != 0);
    return (char)(UART0->DR & 0xFF);
}

static void UAR(char z){
    while(UART0->FR & 0x20);
    UART0->DR = z;
}

static void UART0Print(char *str){
    while(*str){
        UAR(*str++);
    }
}

static void printMenu(void){
    UART0Print("\r\nCommands:\r\n");
    UART0Print("r -> Red LED\r\n");
    UART0Print("g -> Green LED\r\n");
    UART0Print("b -> Blue LED\r\n");
    UART0Print("o -> All off\r\n");
    UART0Print("h -> Print menu again\r\n");
    UART0Print("* -> Funny secret message\r\n");
}