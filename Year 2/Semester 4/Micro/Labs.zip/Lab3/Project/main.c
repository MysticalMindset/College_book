#include <stdio.h>
#include "RTE_Components.h"
#include CMSIS_device_header
#include "delayMs.h"
#include "Activity_1.h"
#include "Activity_2.h"
#include "Activity3_4.h"

int main() {
    Activity1();
    delayMs(30000);
    Activity1_p2();
    delayMs(30000);
    Activity2();
    delayMs(30000);
    Activity34();
}

