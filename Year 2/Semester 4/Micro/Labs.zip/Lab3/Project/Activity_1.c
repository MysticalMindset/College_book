/*
# 1. Hardware Connection
# 2. Find the COM Port
    Before opening PuTTY you must find the COM port.
    ### Steps
    1. Right click **Start**
    2. Open **Device Manager**
    3. Expand **Ports (COM & LPT)**

    Remember the **COM number** (example: COM4).
---
# 3. Configure PuTTY
    Open **PuTTY**.
    Set these settings:
    ### Connection Type
    Serial
    ### Serial Line
    COM4   (use your COM number)
    ### Speed
    9600
    Then click **Serial** on the left and set:
    | Setting      | Value |
    | ------------ | ----- |
    | Speed        | 9600  |
    | Data bits    | 8     |
    | Stop bits    | 1     |
    | Parity       | None  |
    | Flow Control | None  |
    Then click **Open**.
    The terminal window will appear (blank for now).
---
# 4. Program 4-1 (Send "YES" continuously)
    Paste the 4-1.txt into compiler
---
# 5. Build and Upload
    1. Click **Build (hammer icon)**
    2. Flash **TIVA**
    The program will run immediately.
---

# 6. What You Should See in PuTTY

    Your PuTTY window should display:

    ```
    YES
    YES
    YES
    YES
    YES
    YES
    YES
    ```

    continuously scrolling.

    Take a **screenshot** for your report.

---

# 7. Change Baud Rate to 115200

    Now modify these two lines.

    ### Old (9600)

    ```c
    UART0->IBRD = 104;
    UART0->FBRD = 11;
    ```

    ### New (115200)

    ```c
    UART0->IBRD = 8;
    UART0->FBRD = 44;
    ```

---

# 8. Change PuTTY Settings

    Close PuTTY and reopen it with:

    ```
    Speed = 115200
    ```

    All other settings stay the same.

---

# 9. Run Again

    Rebuild and load the program.

    PuTTY should again show:

    ```
    YES
    YES
    YES
    YES
    ```

    continuously.

    If the baud rate is wrong, you will see **random garbage characters**.

---
*/

#include <stdio.h>
#include "TM4C123GH6PM.h"
#include "delayMs.h"
#include "Activity_1.h"

static void UART0Print(char *str);

void Activity1(void){
    SYSCTL->RCGCUART |= 1;  /* provide clock to UART0 */
    SYSCTL->RCGCGPIO |= 1;  /* enable clock to PORTA */
    
    /* UART0 initialization */
    UART0->CTL = 0;         /* disable UART0 */

    /* UART0 TX0 and RX0 use PA0 and PA1. Set them up. */
    GPIOA->DEN = 0x03;      /* Make PA0 and PA1 as digital */
    GPIOA->AFSEL = 0x03;    /* Use PA0,PA1 alternate function */
    GPIOA->PCTL = 0x11;     /* configure PA0 and PA1 for UART */

    UART0->IBRD = 104;      /* 16MHz/16=1MHz, 1MHz/104=9600 baud rate */
    UART0->FBRD = 11;       /* fraction part, see Example 4-4 */
    UART0->CC = 0x5;        /* use PIOSC 16 MHz */
    UART0->LCRH = 0x60;     /* 8-bit, no parity, 1-stop bit, no FIFO */
    
    UART0->CTL = 0x301;     /* enable UART0, TXE, RXE */
    delayMs(100);

    UART0Print("Activity 1: Ongoing\r\n");
    delayMs(100);

    for(int i=1; i <= 3; i++){
        UART0Print("YES\r\n");
        delayMs(1000);
    }

    UART0Print("Activity 1: Completed\r\n");
    delayMs(100);
}

void Activity1_p2(void){
    SYSCTL->RCGCUART |= 1;  /* provide clock to UART0 */
    SYSCTL->RCGCGPIO |= 1;  /* enable clock to PORTA */
    
    /* UART0 initialization */
    UART0->CTL = 0;         /* disable UART0 */

    /* UART0 TX0 and RX0 use PA0 and PA1. Set them up. */
    GPIOA->DEN = 0x03;      /* Make PA0 and PA1 as digital */
    GPIOA->AFSEL = 0x03;    /* Use PA0,PA1 alternate function */
    GPIOA->PCTL = 0x11;     /* configure PA0 and PA1 for UART */

    UART0->IBRD = 8;        /* 16MHz/16=1MHz, 1MHz/8=115200 baud rate */
    UART0->FBRD = 44;       /* fraction part, see Example 4-4 */
    UART0->CC = 0;        /* use PIOSC 16 MHz */
    UART0->LCRH = 0x60;     /* 8-bit, no parity, 1-stop bit, no FIFO */
    
    UART0->CTL = 0x301;     /* enable UART0, TXE, RXE */
    delayMs(100);

    UART0Print("Activity 1 [Part 2]: Ongoing\r\n");
    delayMs(100);

    for(int i=1; i <= 3; i++){
        UART0Print("YES\r\n");
        delayMs(1000);
    }

    UART0Print("Activity 1 [Part 2]: Completed\r\n");
    delayMs(100);
}

static void UART0Tx(char c){
    while (UART0->FR & 0x20) {}
    UART0->DR = c;
}

static void UART0Print(char *str){
    while (*str){
        UART0Tx(*str++);
    }
}