#include <stdio.h>

// delay n milliseconds (16 MHz CPU clock)
void delayMs(int n){
    int i, j;
    for(i = 0 ; i < n; i++)
        for(j = 0; j < 3180; j++)
    {} // do nothing for 1 ms
}