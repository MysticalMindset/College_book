/*******************************************************************************
 * adc.c — ADC0 Sequencer 3, AIN0 (PE3), 64× hardware averaging
 ******************************************************************************/

#include "config.h"
#include "adc.h"

void ADC0_Init(void)
{
    SYSCTL->RCGCADC  |= 0x01;
    SYSCTL->RCGCGPIO |= 0x10;          /* Port E (may already be on) */
    while ((SYSCTL->PRGPIO & 0x10) == 0) {}

    GPIOE->DIR   &= ~0x08;             /* PE3 input */
    GPIOE->AFSEL |=  0x08;
    GPIOE->DEN   &= ~0x08;
    GPIOE->AMSEL |=  0x08;

    while ((SYSCTL->PRADC & 0x01) == 0) {}

    ADC0->SAC    =  6;                 /* 64× hardware oversampling */

    ADC0->ACTSS  &= ~0x08;            /* disable SS3 during config */
    ADC0->EMUX   &= ~0xF000u;         /* software trigger */
    ADC0->SSMUX3  =  0;               /* AIN0 = PE3 */
    ADC0->SSCTL3  =  0x06;            /* IE0 | END0 */
    ADC0->ACTSS  |=  0x08;            /* re-enable SS3 */
}

uint32_t ADC0_ReadPot(void)
{
    uint32_t result;
    ADC0->PSSI = 0x08;
    while ((ADC0->RIS & 0x08) == 0) {}
    result = ADC0->SSFIFO3 & 0xFFFu;
    ADC0->ISC = 0x08;
    return result;
}

/* 8-sample software average on top of hardware averaging */
uint32_t ADC0_ReadPotAvg(void)
{
    uint32_t sum = 0;
    int i;
    for (i = 0; i < 8; i++)
        sum += ADC0_ReadPot();
    return sum / 8u;
}
