/*******************************************************************************
 * delay.h — SysTick-based microsecond / millisecond delay
 ******************************************************************************/

#ifndef DELAY_H
#define DELAY_H

#include <stdint.h>

void     SysTick_Init(void);
void     delayUs(uint32_t us);
void     delayMs(int n);

#endif /* DELAY_H */