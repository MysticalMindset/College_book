/*******************************************************************************
 * utils.h — Numeric-to-string helpers (no stdlib required)
 ******************************************************************************/

#ifndef UTILS_H
#define UTILS_H

#include <stdint.h>

void floatToStr1(float val, char *buf);     /* 1 decimal place, e.g. "23.5" */
void intToStr(uint32_t num, char *str);

#endif /* UTILS_H */