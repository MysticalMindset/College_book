/*******************************************************************************
 * pid.h — PID controller
 ******************************************************************************/

#ifndef PID_H
#define PID_H

float PID_Compute(float setpoint, float measured, float dt);

#endif /* PID_H */