/*******************************************************************************
 * lcd.h — I2C0 driver (PB2/PB3) and LCD helper API
 ******************************************************************************/

#ifndef LCD_H
#define LCD_H

#include <stdint.h>

/* ---- I2C0 ---- */
void I2C0_Init_50kHz(void);
void I2C0_WriteBuffer(uint8_t slave_addr, uint8_t *data, uint32_t len);

/* ---- LCD ---- */
void LCD_Init(void);
void LCD_Clear(void);
void LCD_ClearLine(uint8_t lineAddr);
void LCD_SetCursor(uint8_t pos);
void LCD_Print(char *str);
void LCD_SendCommand(uint8_t cmd);
void LCD_SendCommand1(uint8_t cmd, uint8_t param);
void LCD_Update(float curTemp, float setTemp, float duty, uint8_t status);

#endif /* LCD_H */