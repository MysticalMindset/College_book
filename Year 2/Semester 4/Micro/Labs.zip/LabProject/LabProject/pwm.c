/*******************************************************************************
 * pwm.c — Software PWM on PB6
 *
 * Period = 100 ms (10 Hz). The slow period gives the motor real torque per
 * pulse while keeping the cycle fast enough for responsive control.
 ******************************************************************************/

#include "config.h"
#include "delay.h"
#include "pwm.h"

static volatile uint32_t g_pwmDuty = 0;   /* 0 – 100 */

void PWM0_Init(void)
{
    /* Port B clock is already enabled by I2C0 init */
    GPIOB->AFSEL &= ~0x40u;
    GPIOB->DIR   |=  0x40u;
    GPIOB->DEN   |=  0x40u;
    GPIOB->AMSEL &= ~0x40u;
    GPIOB->DATA  &= ~0x40u;            /* start low = fan off */
}

void PWM0_SetDuty(float pct)
{
    if      (pct <= 0.0f)   g_pwmDuty = 0;
    else if (pct > 100.0f)  g_pwmDuty = 100;
    else                    g_pwmDuty = (uint32_t)(pct + 0.5f);
}

void PWM0_RunCycle(void)
{
    uint32_t onTimeMs, offTimeMs;

    if (g_pwmDuty == 0)
    {
        GPIOB->DATA &= ~0x40u;         /* fully off */
        delayMs(100);
        return;
    }
    if (g_pwmDuty >= 100)
    {
        GPIOB->DATA |= 0x40u;          /* fully on */
        delayMs(100);
        return;
    }

    onTimeMs  = g_pwmDuty;             /* ms  (e.g. 75 % → 75 ms on) */
    offTimeMs = 100u - g_pwmDuty;

    GPIOB->DATA |=  0x40u;            /* HIGH */
    delayMs(onTimeMs);
    GPIOB->DATA &= ~0x40u;            /* LOW */
    delayMs(offTimeMs);
}

/*
 * Blast 100 % for 500 ms to overcome motor inertia before throttling
 * back to the PID-requested duty.
 */
void PWM0_KickStart(void)
{
    GPIOB->DATA |= 0x40u;
    delayMs(500);
}