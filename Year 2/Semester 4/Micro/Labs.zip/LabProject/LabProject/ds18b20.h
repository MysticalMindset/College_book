/*******************************************************************************
 * ds18b20.h — DS18B20 temperature sensor driver (1-Wire bit-bang on PE1)
 ******************************************************************************/

#ifndef DS18B20_H
#define DS18B20_H

#include <stdint.h>

/* ---- 1-Wire bus primitives ---- */
void    OW_Init(void);
uint8_t OW_Reset(void);
void    OW_WriteByte(uint8_t byte);
uint8_t OW_ReadByte(void);

/* ---- DS18B20 high-level API ---- */
/*
 * Triggers a 12-bit temperature conversion.
 * Actively drives the line high during the 750 ms conversion window
 * to supply the strong pull-up current required by the sensor.
 */
void  DS18B20_StartConvert(void);

/*
 * Reads the scratchpad and returns temperature in °C.
 * Return values:
 *   >= -900  : valid temperature
 *   -998.0   : power-on default (0x0550) — conversion not yet complete
 *   -999.0   : no sensor presence detected
 */
float DS18B20_ReadTemp(void);

#endif /* DS18B20_H */