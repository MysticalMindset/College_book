/*******************************************************************************
 * delay.c — SysTick-based microsecond / millisecond delay
 ******************************************************************************/

#include "config.h"
#include "delay.h"

void SysTick_Init(void)
{
    SysTick->CTRL = 0;
    SysTick->LOAD = 0x00FFFFFF;
    SysTick->VAL  = 0;
    SysTick->CTRL = 0x05;              /* enable, system clock, no IRQ */
}

void delayUs(uint32_t us)
{
    uint32_t ticks = us * 16;           /* 16 MHz */
    if (ticks > 0x00FFFFFF) ticks = 0x00FFFFFF;
    SysTick->LOAD = ticks - 1;
    SysTick->VAL  = 0;
    while ((SysTick->CTRL & 0x10000) == 0) {}
}

void delayMs(int n)
{
    int i;
    for (i = 0; i < n; i++)
        delayUs(1000);
}