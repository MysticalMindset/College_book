/*******************************************************************************
 * adc.h — ADC0 driver for potentiometer on PE3 (AIN0)
 ******************************************************************************/

#ifndef ADC_H
#define ADC_H

#include <stdint.h>

void     ADC0_Init(void);
uint32_t ADC0_ReadPot(void);
uint32_t ADC0_ReadPotAvg(void);    /* 8-sample software average */

#endif /* ADC_H */
