/*******************************************************************************
 * lcd.c — I2C0 driver (PB2 = SCL, PB3 = SDA) and LCD helper functions
 *
 * LCD I2C address : LCD_ADDR (0x28)  — defined in config.h
 * Command prefix  : 0xFE
 ******************************************************************************/

#include "config.h"
#include "delay.h"
#include "utils.h"
#include "lcd.h"

/* ====================================================================== */
/*  I2C0  (PB2 = SCL, PB3 = SDA)                                          */
/* ====================================================================== */

void I2C0_Init_50kHz(void)
{
    SYSCTL->RCGCI2C  |= 0x01;
    SYSCTL->RCGCGPIO |= 0x02;
    while ((SYSCTL->PRGPIO & 0x02) == 0) {}

    GPIOB->AFSEL |=  0x0C;
    GPIOB->DEN   |=  0x0C;
    GPIOB->ODR   |=  0x08;
    GPIOB->AMSEL &= ~0x0C;
    GPIOB->PCTL  &= ~0x0000FF00u;
    GPIOB->PCTL  |=  0x00003300u;

    I2C0->MCR  = 0x10;
    I2C0->MTPR = 15;
}

void I2C0_WriteBuffer(uint8_t slave_addr, uint8_t *data, uint32_t len)
{
    uint32_t i;
    if (len == 0) return;

    I2C0->MSA = (slave_addr << 1) & ~0x01u;
    I2C0->MDR = data[0];

    if (len == 1)
    {
        I2C0->MCS = 0x07;
        while (I2C0->MCS & 0x01) {}
        return;
    }

    I2C0->MCS = 0x03;
    while (I2C0->MCS & 0x01) {}

    for (i = 1; i < len - 1; i++)
    {
        I2C0->MDR = data[i];
        I2C0->MCS = 0x01;
        while (I2C0->MCS & 0x01) {}
    }

    I2C0->MDR = data[len - 1];
    I2C0->MCS = 0x05;
    while (I2C0->MCS & 0x01) {}
}

/* ====================================================================== */
/*  LCD low-level helpers                                                   */
/* ====================================================================== */

void LCD_SendCommand(uint8_t cmd)
{
    uint8_t buf[2] = {0xFE, cmd};
    I2C0_WriteBuffer(LCD_ADDR, buf, 2);
    delayMs(2);
}

void LCD_SendCommand1(uint8_t cmd, uint8_t param)
{
    uint8_t buf[3] = {0xFE, cmd, param};
    I2C0_WriteBuffer(LCD_ADDR, buf, 3);
    delayMs(2);
}

void LCD_Clear(void)
{
    LCD_SendCommand(0x51);
    delayMs(2);
}

void LCD_SetCursor(uint8_t pos)
{
    LCD_SendCommand1(0x45, pos);
}

void LCD_Print(char *str)
{
    while (*str)
    {
        uint8_t ch = (uint8_t)(*str++);
        I2C0_WriteBuffer(LCD_ADDR, &ch, 1);
        delayMs(1);
    }
}

void LCD_ClearLine(uint8_t lineAddr)
{
    int i;
    LCD_SetCursor(lineAddr);
    for (i = 0; i < 16; i++)
    {
        uint8_t ch = ' ';
        I2C0_WriteBuffer(LCD_ADDR, &ch, 1);
        delayMs(1);
    }
}

/* ====================================================================== */
/*  LCD initialisation                                                      */
/* ====================================================================== */

void LCD_Init(void)
{
    delayMs(100);
    LCD_SendCommand(0x41);
    LCD_SendCommand1(0x52, 40);
    LCD_SendCommand1(0x53, 8);
    LCD_Clear();
}

/* ====================================================================== */
/*  Application-level display update                                        */
/*                                                                          */
/*  status: 0 = no sensor, 1 = normal, 2 = startup / not yet converted     */
/* ====================================================================== */

void LCD_Update(float curTemp, float setTemp, float duty, uint8_t status)
{
    char buf[8];
    char dutyBuf[5];

    /* ---- Line 1 ---- */
    LCD_ClearLine(0x00);
    LCD_SetCursor(0x00);

    if (status == 0)
    {
        LCD_Print("Cur:NO SENSOR");
    }
    else if (status == 2)
    {
        LCD_Print("Cur:STARTUP...");
    }
    else
    {
        LCD_Print("Cur:");
        floatToStr1(curTemp, buf);
        LCD_Print(buf);
        LCD_Print("C ");
        intToStr((uint32_t)(duty + 0.5f), dutyBuf);
        LCD_Print(dutyBuf);
        LCD_Print("%");
    }

    /* ---- Line 2 ---- */
    LCD_ClearLine(0x40);
    LCD_SetCursor(0x40);
    LCD_Print("Set:");
    floatToStr1(setTemp, buf);
    LCD_Print(buf);
    LCD_Print("C PID");
}