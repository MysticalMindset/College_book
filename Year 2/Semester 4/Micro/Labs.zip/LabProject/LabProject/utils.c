/*******************************************************************************
 * utils.c — Numeric-to-string helpers (no stdlib / printf dependency)
 ******************************************************************************/

#include "utils.h"

/*
 * floatToStr1 — convert float to string with 1 decimal place.
 * Supports negative values and saturates at ±999.9.
 * buf must be at least 7 bytes.
 */
void floatToStr1(float val, char *buf)
{
    int     intPart, fracPart, i, len;
    char    temp[8];
    uint8_t neg = 0;

    if (val < 0.0f) { neg = 1; val = -val; }
    if (val > 999.9f) val = 999.9f;

    intPart  = (int)val;
    fracPart = (int)((val - (float)intPart) * 10.0f + 0.5f);
    if (fracPart >= 10) { intPart++; fracPart = 0; }

    i = 0;
    if (intPart == 0)
    {
        temp[i++] = '0';
    }
    else
    {
        while (intPart > 0) { temp[i++] = (char)((intPart % 10) + '0'); intPart /= 10; }
    }

    len = 0;
    if (neg) buf[len++] = '-';
    for (i = i - 1; i >= 0; i--)
        buf[len++] = temp[i];
    buf[len++] = '.';
    buf[len++] = (char)(fracPart + '0');
    buf[len]   = '\0';
}

/*
 * intToStr — convert unsigned integer to decimal string.
 * buf must be at least 11 bytes.
 */
void intToStr(uint32_t num, char *str)
{
    int  i = 0, j;
    char temp[10];

    if (num == 0) { str[0] = '0'; str[1] = '\0'; return; }

    while (num > 0) { temp[i++] = (char)((num % 10) + '0'); num /= 10; }
    for (j = 0; j < i; j++) str[j] = temp[i - j - 1];
    str[i] = '\0';
}