/*******************************************************************************
 * pid.c — Discrete PID controller with anti-windup and dead-band clamping
 *
 * Gains and limits are defined in config.h (KP, KI, KD, MIN_DUTY, MAX_DUTY).
 *
 * Error convention: error = measured − setpoint
 *   → positive error means temperature is ABOVE setpoint → increase fan duty
 ******************************************************************************/

#include "config.h"
#include "pid.h"

static float g_integral  = 0.0f;
static float g_prevError = 0.0f;

float PID_Compute(float setpoint, float measured, float dt)
{
    float error, pTerm, iTerm, dTerm, output;

    error = measured - setpoint;

    /* Proportional */
    pTerm = KP * error;

    /* Integral with symmetric anti-windup clamp */
    g_integral += error * dt;
    if (g_integral >  80.0f) g_integral =  80.0f;
    if (g_integral < -80.0f) g_integral = -80.0f;
    iTerm = KI * g_integral;

    /* Derivative */
    dTerm = KD * (error - g_prevError) / dt;
    g_prevError = error;

    output = pTerm + iTerm + dTerm;

    /* Clamp output and clear integral if fan should be off */
    if (output < 0.0f)
    {
        output = 0.0f;
        if (g_integral < 0.0f) g_integral = 0.0f;  /* conditional reset */
    }
    else if (output < MIN_DUTY)
    {
        /* Below minimum: either hold at MIN_DUTY (if error warrants) or off */
        output = (error > 1.0f) ? MIN_DUTY : 0.0f;
    }

    if (output > MAX_DUTY) output = MAX_DUTY;

    return output;
}