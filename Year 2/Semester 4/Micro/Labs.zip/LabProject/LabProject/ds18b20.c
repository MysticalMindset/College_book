/*******************************************************************************
 * ds18b20.c — DS18B20 temperature sensor (1-Wire bit-bang on PE1)
 ******************************************************************************/

#include "config.h"
#include "delay.h"
#include "ds18b20.h"

/* ====================================================================== */
/*  1-Wire bus initialisation                                               */
/* ====================================================================== */

void OW_Init(void)
{
    SYSCTL->RCGCGPIO |= 0x10;          /* enable Port E clock */
    while ((SYSCTL->PRGPIO & 0x10) == 0) {}

    OW_PORT->AFSEL &= ~OW_PIN;
    OW_PORT->AMSEL &= ~OW_PIN;
    OW_PORT->DEN   |=  OW_PIN;
    OW_PORT->PUR   |=  OW_PIN;         /* internal pull-up (backup) */
    OW_PORT->DIR   &= ~OW_PIN;         /* default: input (idle high) */
}

/* ====================================================================== */
/*  1-Wire line drive helpers (static — internal use only)                  */
/* ====================================================================== */

static void OW_DriveLow(void)
{
    OW_PORT->DIR |=  OW_PIN;
    OW_DATA       =  0;
}

/* Actively drive high during DS18B20 conversion (strong pull-up) */
static void OW_DriveHigh(void)
{
    OW_DATA       =  OW_PIN;
    OW_PORT->DIR |=  OW_PIN;
}

static void OW_Release(void)
{
    OW_PORT->DIR &= ~OW_PIN;           /* tri-state; external resistor holds high */
}

static uint8_t OW_ReadPin(void)
{
    return (OW_DATA) ? 1u : 0u;
}

/* ====================================================================== */
/*  1-Wire bus primitives                                                   */
/* ====================================================================== */

uint8_t OW_Reset(void)
{
    uint8_t presence;

    OW_DriveLow();
    delayUs(480);
    OW_Release();
    delayUs(70);
    presence = (OW_ReadPin() == 0) ? 1u : 0u;
    delayUs(410);
    return presence;
}

static void OW_WriteBit(uint8_t bit)
{
    if (bit)
    {
        OW_DriveLow();
        delayUs(6);
        OW_Release();
        delayUs(64);
    }
    else
    {
        OW_DriveLow();
        delayUs(60);
        OW_Release();
        delayUs(10);
    }
}

static uint8_t OW_ReadBit(void)
{
    uint8_t bit;

    OW_DriveLow();
    delayUs(2);
    OW_Release();
    delayUs(12);
    bit = OW_ReadPin();
    delayUs(56);
    return bit;
}

void OW_WriteByte(uint8_t byte)
{
    int i;
    for (i = 0; i < 8; i++)
    {
        OW_WriteBit(byte & 0x01u);
        byte >>= 1;
    }
}

uint8_t OW_ReadByte(void)
{
    uint8_t byte = 0;
    int i;
    for (i = 0; i < 8; i++)
    {
        byte >>= 1;
        if (OW_ReadBit())
            byte |= 0x80u;
    }
    return byte;
}

/* ====================================================================== */
/*  DS18B20 high-level API                                                  */
/* ====================================================================== */

void DS18B20_StartConvert(void)
{
    OW_Reset();
    OW_WriteByte(OW_CMD_SKIP_ROM);
    OW_WriteByte(OW_CMD_CONVERT_T);

    /* Strong pull-up during 12-bit conversion (750 ms max) */
    OW_DriveHigh();
    delayMs(750);
    OW_Release();
}

float DS18B20_ReadTemp(void)
{
    uint8_t  sp[9];
    int16_t  raw;
    int      i;

    if (!OW_Reset())
        return -999.0f;

    OW_WriteByte(OW_CMD_SKIP_ROM);
    OW_WriteByte(OW_CMD_READ_SCRATCH);

    for (i = 0; i < 9; i++)
        sp[i] = OW_ReadByte();

    OW_Reset();

    /* All-0xFF → no sensor responding */
    if (sp[0] == 0xFF && sp[1] == 0xFF)
        return -999.0f;

    raw = ((int16_t)sp[1] << 8) | sp[0];

    /* 0x0550 = 85.0 °C power-on default → conversion not yet complete */
    if (raw == 0x0550)
        return -998.0f;

    return (float)raw * 0.0625f;
}