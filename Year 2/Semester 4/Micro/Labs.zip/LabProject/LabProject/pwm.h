/*******************************************************************************
 * pwm.h — Software PWM on PB6 (10 Hz, blocking cycle)
 ******************************************************************************/

#ifndef PWM_H
#define PWM_H

#include <stdint.h>

void PWM0_Init(void);
void PWM0_SetDuty(float pct);       /* 0.0 – 100.0 */
void PWM0_RunCycle(void);           /* blocks for one 100 ms period */
void PWM0_KickStart(void);          /* 500 ms full-power kick to overcome inertia */

#endif /* PWM_H */