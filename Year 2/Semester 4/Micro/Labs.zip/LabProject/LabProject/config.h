/*******************************************************************************
 * config.h — Global configuration and pin definitions
 *
 * PID Fan Controller — TM4C123GH6PM
 ******************************************************************************/

#ifndef CONFIG_H
#define CONFIG_H

#include "RTE_Components.h"
#include  CMSIS_device_header
#include <stdint.h>

/* ---- LCD ---- */
#define LCD_ADDR        0x28

/* ---- PID Tuning ---- */
#define KP              8.0f
#define KI              0.3f
#define KD              1.0f

/* ---- Setpoint range from pot (degrees C) ---- */
#define MIN_SET_C       20.0f
#define MAX_SET_C       60.0f

/* ---- Fan limits ---- */
#define MIN_DUTY        90.0f           /* fan stalls below 90% with L298N */
#define MAX_DUTY        100.0f

/* ---- PWM ---- */
/* 16 MHz / 8 = 2 MHz PWM clock.  2 MHz / 20000 = 100 Hz */
#define PWM_LOAD        20000

/* ---- DS18B20 1-Wire commands ---- */
#define OW_CMD_SKIP_ROM     0xCC
#define OW_CMD_CONVERT_T    0x44
#define OW_CMD_READ_SCRATCH 0xBE

/* ---- 1-Wire pin: PE1 ---- */
#define OW_PORT         GPIOE
#define OW_PIN          (1u << 1)
/* Port E bit-banded data register */
#define OW_DATA         (*((volatile uint32_t *)(0x40024000u + (OW_PIN << 2))))

#endif /* CONFIG_H */