# groups.cmake

# group Source Files
add_library(Group_Source_Files OBJECT
  "${SOLUTION_ROOT}/LabProject/main.c"
)
target_include_directories(Group_Source_Files PUBLIC
  $<TARGET_PROPERTY:${CONTEXT},INTERFACE_INCLUDE_DIRECTORIES>
  "${SOLUTION_ROOT}/LabProject"
)
target_compile_definitions(Group_Source_Files PUBLIC
  $<TARGET_PROPERTY:${CONTEXT},INTERFACE_COMPILE_DEFINITIONS>
)
add_library(Group_Source_Files_ABSTRACTIONS INTERFACE)
target_link_libraries(Group_Source_Files_ABSTRACTIONS INTERFACE
  ${CONTEXT}_ABSTRACTIONS
)
target_compile_options(Group_Source_Files PUBLIC
  $<TARGET_PROPERTY:${CONTEXT},INTERFACE_COMPILE_OPTIONS>
)
target_link_libraries(Group_Source_Files PUBLIC
  Group_Source_Files_ABSTRACTIONS
)

# group delayMs
add_library(Group_Source_Files_delayMs OBJECT
  "${SOLUTION_ROOT}/LabProject/delay.c"
)
target_include_directories(Group_Source_Files_delayMs PUBLIC
  $<TARGET_PROPERTY:Group_Source_Files,INTERFACE_INCLUDE_DIRECTORIES>
  "${SOLUTION_ROOT}/LabProject"
)
target_compile_definitions(Group_Source_Files_delayMs PUBLIC
  $<TARGET_PROPERTY:Group_Source_Files,INTERFACE_COMPILE_DEFINITIONS>
)
add_library(Group_Source_Files_delayMs_ABSTRACTIONS INTERFACE)
target_link_libraries(Group_Source_Files_delayMs_ABSTRACTIONS INTERFACE
  Group_Source_Files_ABSTRACTIONS
)
target_compile_options(Group_Source_Files_delayMs PUBLIC
  $<TARGET_PROPERTY:Group_Source_Files,INTERFACE_COMPILE_OPTIONS>
)
target_link_libraries(Group_Source_Files_delayMs PUBLIC
  Group_Source_Files_delayMs_ABSTRACTIONS
)

# group adc
add_library(Group_Source_Files_adc OBJECT
  "${SOLUTION_ROOT}/LabProject/adc.c"
)
target_include_directories(Group_Source_Files_adc PUBLIC
  $<TARGET_PROPERTY:Group_Source_Files,INTERFACE_INCLUDE_DIRECTORIES>
  "${SOLUTION_ROOT}/LabProject"
)
target_compile_definitions(Group_Source_Files_adc PUBLIC
  $<TARGET_PROPERTY:Group_Source_Files,INTERFACE_COMPILE_DEFINITIONS>
)
add_library(Group_Source_Files_adc_ABSTRACTIONS INTERFACE)
target_link_libraries(Group_Source_Files_adc_ABSTRACTIONS INTERFACE
  Group_Source_Files_ABSTRACTIONS
)
target_compile_options(Group_Source_Files_adc PUBLIC
  $<TARGET_PROPERTY:Group_Source_Files,INTERFACE_COMPILE_OPTIONS>
)
target_link_libraries(Group_Source_Files_adc PUBLIC
  Group_Source_Files_adc_ABSTRACTIONS
)

# group utils
add_library(Group_Source_Files_utils OBJECT
  "${SOLUTION_ROOT}/LabProject/utils.c"
)
target_include_directories(Group_Source_Files_utils PUBLIC
  $<TARGET_PROPERTY:Group_Source_Files,INTERFACE_INCLUDE_DIRECTORIES>
  "${SOLUTION_ROOT}/LabProject"
)
target_compile_definitions(Group_Source_Files_utils PUBLIC
  $<TARGET_PROPERTY:Group_Source_Files,INTERFACE_COMPILE_DEFINITIONS>
)
add_library(Group_Source_Files_utils_ABSTRACTIONS INTERFACE)
target_link_libraries(Group_Source_Files_utils_ABSTRACTIONS INTERFACE
  Group_Source_Files_ABSTRACTIONS
)
target_compile_options(Group_Source_Files_utils PUBLIC
  $<TARGET_PROPERTY:Group_Source_Files,INTERFACE_COMPILE_OPTIONS>
)
target_link_libraries(Group_Source_Files_utils PUBLIC
  Group_Source_Files_utils_ABSTRACTIONS
)

# group pid
add_library(Group_Source_Files_pid OBJECT
  "${SOLUTION_ROOT}/LabProject/pid.c"
)
target_include_directories(Group_Source_Files_pid PUBLIC
  $<TARGET_PROPERTY:Group_Source_Files,INTERFACE_INCLUDE_DIRECTORIES>
  "${SOLUTION_ROOT}/LabProject"
)
target_compile_definitions(Group_Source_Files_pid PUBLIC
  $<TARGET_PROPERTY:Group_Source_Files,INTERFACE_COMPILE_DEFINITIONS>
)
add_library(Group_Source_Files_pid_ABSTRACTIONS INTERFACE)
target_link_libraries(Group_Source_Files_pid_ABSTRACTIONS INTERFACE
  Group_Source_Files_ABSTRACTIONS
)
target_compile_options(Group_Source_Files_pid PUBLIC
  $<TARGET_PROPERTY:Group_Source_Files,INTERFACE_COMPILE_OPTIONS>
)
target_link_libraries(Group_Source_Files_pid PUBLIC
  Group_Source_Files_pid_ABSTRACTIONS
)

# group pwm
add_library(Group_Source_Files_pwm OBJECT
  "${SOLUTION_ROOT}/LabProject/pwm.c"
)
target_include_directories(Group_Source_Files_pwm PUBLIC
  $<TARGET_PROPERTY:Group_Source_Files,INTERFACE_INCLUDE_DIRECTORIES>
  "${SOLUTION_ROOT}/LabProject"
)
target_compile_definitions(Group_Source_Files_pwm PUBLIC
  $<TARGET_PROPERTY:Group_Source_Files,INTERFACE_COMPILE_DEFINITIONS>
)
add_library(Group_Source_Files_pwm_ABSTRACTIONS INTERFACE)
target_link_libraries(Group_Source_Files_pwm_ABSTRACTIONS INTERFACE
  Group_Source_Files_ABSTRACTIONS
)
target_compile_options(Group_Source_Files_pwm PUBLIC
  $<TARGET_PROPERTY:Group_Source_Files,INTERFACE_COMPILE_OPTIONS>
)
target_link_libraries(Group_Source_Files_pwm PUBLIC
  Group_Source_Files_pwm_ABSTRACTIONS
)

# group ds18b20
add_library(Group_Source_Files_ds18b20 OBJECT
  "${SOLUTION_ROOT}/LabProject/ds18b20.c"
)
target_include_directories(Group_Source_Files_ds18b20 PUBLIC
  $<TARGET_PROPERTY:Group_Source_Files,INTERFACE_INCLUDE_DIRECTORIES>
  "${SOLUTION_ROOT}/LabProject"
)
target_compile_definitions(Group_Source_Files_ds18b20 PUBLIC
  $<TARGET_PROPERTY:Group_Source_Files,INTERFACE_COMPILE_DEFINITIONS>
)
add_library(Group_Source_Files_ds18b20_ABSTRACTIONS INTERFACE)
target_link_libraries(Group_Source_Files_ds18b20_ABSTRACTIONS INTERFACE
  Group_Source_Files_ABSTRACTIONS
)
target_compile_options(Group_Source_Files_ds18b20 PUBLIC
  $<TARGET_PROPERTY:Group_Source_Files,INTERFACE_COMPILE_OPTIONS>
)
target_link_libraries(Group_Source_Files_ds18b20 PUBLIC
  Group_Source_Files_ds18b20_ABSTRACTIONS
)

# group LCD
add_library(Group_Source_Files_LCD OBJECT
  "${SOLUTION_ROOT}/LabProject/lcd.c"
)
target_include_directories(Group_Source_Files_LCD PUBLIC
  $<TARGET_PROPERTY:Group_Source_Files,INTERFACE_INCLUDE_DIRECTORIES>
  "${SOLUTION_ROOT}/LabProject"
)
target_compile_definitions(Group_Source_Files_LCD PUBLIC
  $<TARGET_PROPERTY:Group_Source_Files,INTERFACE_COMPILE_DEFINITIONS>
)
add_library(Group_Source_Files_LCD_ABSTRACTIONS INTERFACE)
target_link_libraries(Group_Source_Files_LCD_ABSTRACTIONS INTERFACE
  Group_Source_Files_ABSTRACTIONS
)
target_compile_options(Group_Source_Files_LCD PUBLIC
  $<TARGET_PROPERTY:Group_Source_Files,INTERFACE_COMPILE_OPTIONS>
)
target_link_libraries(Group_Source_Files_LCD PUBLIC
  Group_Source_Files_LCD_ABSTRACTIONS
)
