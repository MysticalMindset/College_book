# groups.cmake

# group Source Files
add_library(Group_Source_Files OBJECT
  "${SOLUTION_ROOT}/Lab5/main.c"
)
target_include_directories(Group_Source_Files PUBLIC
  $<TARGET_PROPERTY:${CONTEXT},INTERFACE_INCLUDE_DIRECTORIES>
)
target_compile_definitions(Group_Source_Files PUBLIC
  $<TARGET_PROPERTY:${CONTEXT},INTERFACE_COMPILE_DEFINITIONS>
)
add_library(Group_Source_Files_ABSTRACTIONS INTERFACE)
target_link_libraries(Group_Source_Files_ABSTRACTIONS INTERFACE
  ${CONTEXT}_ABSTRACTIONS
)
target_compile_options(Group_Source_Files PUBLIC
  $<TARGET_PROPERTY:${CONTEXT},INTERFACE_COMPILE_OPTIONS>
)
target_link_libraries(Group_Source_Files PUBLIC
  Group_Source_Files_ABSTRACTIONS
)

# group delay
add_library(Group_Source_Files_delay OBJECT
  "${SOLUTION_ROOT}/Lab5/delayMs.c"
)
target_include_directories(Group_Source_Files_delay PUBLIC
  $<TARGET_PROPERTY:Group_Source_Files,INTERFACE_INCLUDE_DIRECTORIES>
  "${SOLUTION_ROOT}/Lab5"
)
target_compile_definitions(Group_Source_Files_delay PUBLIC
  $<TARGET_PROPERTY:Group_Source_Files,INTERFACE_COMPILE_DEFINITIONS>
)
add_library(Group_Source_Files_delay_ABSTRACTIONS INTERFACE)
target_link_libraries(Group_Source_Files_delay_ABSTRACTIONS INTERFACE
  Group_Source_Files_ABSTRACTIONS
)
target_compile_options(Group_Source_Files_delay PUBLIC
  $<TARGET_PROPERTY:Group_Source_Files,INTERFACE_COMPILE_OPTIONS>
)
target_link_libraries(Group_Source_Files_delay PUBLIC
  Group_Source_Files_delay_ABSTRACTIONS
)

# group LCD
add_library(Group_Source_Files_LCD OBJECT
  "${SOLUTION_ROOT}/Lab5/lcd.c"
)
target_include_directories(Group_Source_Files_LCD PUBLIC
  $<TARGET_PROPERTY:Group_Source_Files,INTERFACE_INCLUDE_DIRECTORIES>
  "${SOLUTION_ROOT}/Lab5"
)
target_compile_definitions(Group_Source_Files_LCD PUBLIC
  $<TARGET_PROPERTY:Group_Source_Files,INTERFACE_COMPILE_DEFINITIONS>
)
add_library(Group_Source_Files_LCD_ABSTRACTIONS INTERFACE)
target_link_libraries(Group_Source_Files_LCD_ABSTRACTIONS INTERFACE
  Group_Source_Files_ABSTRACTIONS
)
target_compile_options(Group_Source_Files_LCD PUBLIC
  $<TARGET_PROPERTY:Group_Source_Files,INTERFACE_COMPILE_OPTIONS>
)
target_link_libraries(Group_Source_Files_LCD PUBLIC
  Group_Source_Files_LCD_ABSTRACTIONS
)

# group Activities
add_library(Group_Activities OBJECT
  "${SOLUTION_ROOT}/Lab5/Activity_1.c"
  "${SOLUTION_ROOT}/Lab5/Activity_2.c"
  "${SOLUTION_ROOT}/Lab5/Activity_3.c"
)
target_include_directories(Group_Activities PUBLIC
  $<TARGET_PROPERTY:${CONTEXT},INTERFACE_INCLUDE_DIRECTORIES>
  "${SOLUTION_ROOT}/Lab5"
)
target_compile_definitions(Group_Activities PUBLIC
  $<TARGET_PROPERTY:${CONTEXT},INTERFACE_COMPILE_DEFINITIONS>
)
add_library(Group_Activities_ABSTRACTIONS INTERFACE)
target_link_libraries(Group_Activities_ABSTRACTIONS INTERFACE
  ${CONTEXT}_ABSTRACTIONS
)
target_compile_options(Group_Activities PUBLIC
  $<TARGET_PROPERTY:${CONTEXT},INTERFACE_COMPILE_OPTIONS>
)
target_link_libraries(Group_Activities PUBLIC
  Group_Activities_ABSTRACTIONS
)
