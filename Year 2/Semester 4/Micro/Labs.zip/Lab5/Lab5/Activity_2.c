#include <stdio.h>
#include "TM4C123GH6PM.h"
#include "delayMs.h"
#include "Activity_2.h"
#include "lcd.h"

#define SYSCTL_RCGCI2C_R     (*((volatile uint32_t *)0x400FE620))
#define SYSCTL_RCGCGPIO_R    (*((volatile uint32_t *)0x400FE608))
#define SYSCTL_PRGPIO_R      (*((volatile uint32_t *)0x400FEA08))
#define SYSCTL_PRI2C_R       (*((volatile uint32_t *)0x400FEA20))

#define GPIO_PORTB_AFSEL_R   (*((volatile uint32_t *)0x40005420))
#define GPIO_PORTB_DEN_R     (*((volatile uint32_t *)0x4000551C))
#define GPIO_PORTB_ODR_R     (*((volatile uint32_t *)0x4000550C))
#define GPIO_PORTB_PCTL_R    (*((volatile uint32_t *)0x4000552C))
#define GPIO_PORTB_AMSEL_R   (*((volatile uint32_t *)0x40005528))

#define I2C0_MSA_R           (*((volatile uint32_t *)0x40020000))
#define I2C0_MCS_R           (*((volatile uint32_t *)0x40020004))
#define I2C0_MDR_R           (*((volatile uint32_t *)0x40020008))
#define I2C0_MTPR_R          (*((volatile uint32_t *)0x4002000C))
#define I2C0_MCR_R           (*((volatile uint32_t *)0x40020020))

#define LCD_ADDR 0x27

#define RS 0x01
#define RW 0x02
#define EN 0x04
#define BL 0x08

/* LCD is 16 columns wide */
#define LCD_COLS 20

void LCD_PrintCentered(uint8_t row, char *str);
int  intToStr(int value, char *buf);

void Activity2(void){
    I2C0_Init();
    I2C0_LCD_Init();

    /* Display "Counter:" centered on line 1 (row 0)    */
    /* "Counter:" has 8 characters -> start col = (16-8)/2 = 4 */
    LCD_PrintCentered(0, "Counter:");

    int counter = 0;
    char numBuf[12];

    while(1)
    {
        intToStr(counter, numBuf);

        /* Display counter value centered on line 2 (row 1) */
        LCD_PrintCentered(1, numBuf);

        counter++;
        delayMs(1000);   // 1 second delay
    }
}

/*
 * LCD_PrintCentered: prints str centered on given row (0 or 1)
 * Centering formula: start_col = (LCD_COLS - len) / 2
 */
void LCD_PrintCentered(uint8_t row, char *str)
{
    int len = 0;
    char *p = str;
    while(*p++) len++;

    int start = (LCD_COLS - len) / 2;
    if(start < 0) start = 0;

    /* Clear the line first by writing spaces */
    I2C0_LCD_SetCursor(row, 0);
    int i;
    for(i = 0; i < LCD_COLS; i++)
        I2C0_LCD_SendData(' ');

    I2C0_LCD_SetCursor(row, (uint8_t)start);
    I2C0_LCD_Print(str);
}

/*
 * intToStr: converts integer to decimal string, returns length
 * Handles 0 and positive integers (counter won't go negative)
 */
int intToStr(int value, char *buf)
{
    if(value == 0)
    {
        buf[0] = '0';
        buf[1] = '\0';
        return 1;
    }

    char tmp[12];
    int i = 0, len = 0;

    while(value > 0)
    {
        tmp[i++] = '0' + (value % 10);
        value /= 10;
    }
    len = i;

    /* Reverse */
    int j;
    for(j = 0; j < len; j++)
        buf[j] = tmp[len - 1 - j];
    buf[len] = '\0';

    return len;
}
