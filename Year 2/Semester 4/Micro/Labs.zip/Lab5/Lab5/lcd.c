//lcd.c
#include "lcd.h"
#include <stdint.h>
#include "delayMs.h"

// SYSCTL
#define SYSCTL_RCGCI2C_R     (*((volatile uint32_t *)0x400FE620))
#define SYSCTL_RCGCGPIO_R    (*((volatile uint32_t *)0x400FE608))
#define SYSCTL_PRGPIO_R      (*((volatile uint32_t *)0x400FEA08))
#define SYSCTL_PRI2C_R       (*((volatile uint32_t *)0x400FEA20))

// Port B (I2C0: PB2=SCL, PB3=SDA)
#define GPIO_PORTB_AFSEL_R   (*((volatile uint32_t *)0x40005420))
#define GPIO_PORTB_DEN_R     (*((volatile uint32_t *)0x4000551C))
#define GPIO_PORTB_ODR_R     (*((volatile uint32_t *)0x4000550C))
#define GPIO_PORTB_PCTL_R    (*((volatile uint32_t *)0x4000552C))
#define GPIO_PORTB_AMSEL_R   (*((volatile uint32_t *)0x40005528))

// Port A (I2C1: PA6=SCL, PA7=SDA)
#define GPIO_PORTA_AFSEL_R   (*((volatile uint32_t *)0x40004420))
#define GPIO_PORTA_DEN_R     (*((volatile uint32_t *)0x4000451C))
#define GPIO_PORTA_ODR_R     (*((volatile uint32_t *)0x4000450C))
#define GPIO_PORTA_PCTL_R    (*((volatile uint32_t *)0x4000452C))
#define GPIO_PORTA_AMSEL_R   (*((volatile uint32_t *)0x40004528))

// I2C0 registers
#define I2C0_MSA_R           (*((volatile uint32_t *)0x40020000))
#define I2C0_MCS_R           (*((volatile uint32_t *)0x40020004))
#define I2C0_MDR_R           (*((volatile uint32_t *)0x40020008))
#define I2C0_MTPR_R          (*((volatile uint32_t *)0x4002000C))
#define I2C0_MCR_R           (*((volatile uint32_t *)0x40020020))

// I2C1 registers
#define I2C1_MSA_R           (*((volatile uint32_t *)0x40021000))
#define I2C1_MCS_R           (*((volatile uint32_t *)0x40021004))
#define I2C1_MDR_R           (*((volatile uint32_t *)0x40021008))
#define I2C1_MTPR_R          (*((volatile uint32_t *)0x4002100C))
#define I2C1_MCR_R           (*((volatile uint32_t *)0x40021020))

#define LCD_ADDR 0x27
#define RS 0x01
#define EN 0x04
#define BL 0x08

// ── I2C0 (Port B) ──────────────────────────────────────────────────
void I2C0_Init(void)
{
    SYSCTL_RCGCI2C_R  |= 0x01;
    SYSCTL_RCGCGPIO_R |= 0x02;
    while((SYSCTL_PRGPIO_R & 0x02) == 0);
    while((SYSCTL_PRI2C_R  & 0x01) == 0);
    GPIO_PORTB_AFSEL_R |=  0x0C;
    GPIO_PORTB_DEN_R   |=  0x0C;
    GPIO_PORTB_ODR_R   |=  0x08;
    GPIO_PORTB_AMSEL_R &= ~0x0C;
    GPIO_PORTB_PCTL_R  &= ~0x0000FF00;
    GPIO_PORTB_PCTL_R  |=  0x00003300;
    I2C0_MCR_R  = 0x10;
    I2C0_MTPR_R = 7;
}

void I2C0_WriteByte(uint8_t slave_addr, uint8_t data)
{
    I2C0_MSA_R = (slave_addr << 1) & ~0x01;
    I2C0_MDR_R = data;
    I2C0_MCS_R = 0x07;
    while(I2C0_MCS_R & 0x01);
    while(I2C0_MCS_R & 0x02);
}

// ── I2C1 (Port A) ──────────────────────────────────────────────────
void I2C1_Init(void)
{
    SYSCTL_RCGCI2C_R  |= 0x02;
    SYSCTL_RCGCGPIO_R |= 0x01;
    while((SYSCTL_PRGPIO_R & 0x01) == 0);
    while((SYSCTL_PRI2C_R  & 0x02) == 0);
    GPIO_PORTA_AFSEL_R |=  0xC0;
    GPIO_PORTA_DEN_R   |=  0xC0;
    GPIO_PORTA_ODR_R   |=  0x80;
    GPIO_PORTA_AMSEL_R &= ~0xC0;
    GPIO_PORTA_PCTL_R  &= ~0xFF000000;
    GPIO_PORTA_PCTL_R  |=  0x33000000;
    I2C1_MCR_R  = 0x10;
    I2C1_MTPR_R = 7;
}

void I2C1_WriteByte(uint8_t slave_addr, uint8_t data)
{
    I2C1_MSA_R = (slave_addr << 1) & ~0x01;
    I2C1_MDR_R = data;
    I2C1_MCS_R = 0x07;
    while(I2C1_MCS_R & 0x01);
    while(I2C1_MCS_R & 0x02);
}

// ── LCD helpers ──────────────────────────────
void I2C0_LCD_ExpanderWrite(uint8_t data)
{
    I2C0_WriteByte(LCD_ADDR, data | BL);
}

// ── LCD helpers ──────────────────────────────
void I2C1_LCD_ExpanderWrite(uint8_t data)
{
    I2C1_WriteByte(LCD_ADDR, data | BL);
}

void I2C0_LCD_PulseEnable(uint8_t data)
{
    I2C0_LCD_ExpanderWrite(data | EN);
    delayMs(1);
    I2C0_LCD_ExpanderWrite(data & ~EN);
    delayMs(1);
}

void I2C1_LCD_PulseEnable(uint8_t data)
{
    I2C1_LCD_ExpanderWrite(data | EN);
    delayMs(1);
    I2C1_LCD_ExpanderWrite(data & ~EN);
    delayMs(1);
}

void I2C0_LCD_Write4Bits(uint8_t nibble)
{
    I2C0_LCD_ExpanderWrite(nibble);
    I2C0_LCD_PulseEnable(nibble);
}

void I2C1_LCD_Write4Bits(uint8_t nibble)
{
    I2C1_LCD_ExpanderWrite(nibble);
    I2C1_LCD_PulseEnable(nibble);
}

void I2C0_LCD_SendCommand(uint8_t cmd)
{
    uint8_t high = cmd & 0xF0;
    uint8_t low  = (cmd << 4) & 0xF0;
    I2C0_LCD_Write4Bits(high);
    I2C0_LCD_Write4Bits(low);
    delayMs(2);
}

void I2C1_LCD_SendCommand(uint8_t cmd)
{
    uint8_t high = cmd & 0xF0;
    uint8_t low  = (cmd << 4) & 0xF0;
    I2C1_LCD_Write4Bits(high);
    I2C1_LCD_Write4Bits(low);
    delayMs(2);
}

void I2C0_LCD_SendData(uint8_t data)
{
    uint8_t high = (data & 0xF0) | RS;
    uint8_t low  = ((data << 4) & 0xF0) | RS;
    I2C0_LCD_Write4Bits(high);
    I2C0_LCD_Write4Bits(low);
    delayMs(2);
}

void I2C1_LCD_SendData(uint8_t data)
{
    uint8_t high = (data & 0xF0) | RS;
    uint8_t low  = ((data << 4) & 0xF0) | RS;
    I2C1_LCD_Write4Bits(high);
    I2C1_LCD_Write4Bits(low);
    delayMs(2);
}

void I2C0_LCD_Init(void)
{
    delayMs(50);
    I2C0_LCD_Write4Bits(0x30); delayMs(5);
    I2C0_LCD_Write4Bits(0x30); delayMs(1);
    I2C0_LCD_Write4Bits(0x30); delayMs(1);
    I2C0_LCD_Write4Bits(0x20);
    I2C0_LCD_SendCommand(0x28);
    I2C0_LCD_SendCommand(0x0C);
    I2C0_LCD_SendCommand(0x06);
    I2C0_LCD_SendCommand(0x01);
    delayMs(2);
}

void I2C1_LCD_Init(void)
{
    delayMs(50);
    I2C1_LCD_Write4Bits(0x30); delayMs(5);
    I2C1_LCD_Write4Bits(0x30); delayMs(1);
    I2C1_LCD_Write4Bits(0x30); delayMs(1);
    I2C1_LCD_Write4Bits(0x20);
    I2C1_LCD_SendCommand(0x28);
    I2C1_LCD_SendCommand(0x0C);
    I2C1_LCD_SendCommand(0x06);
    I2C1_LCD_SendCommand(0x01);
    delayMs(2);
}

void I2C0_LCD_Print(const char *str)
{
    while(*str)
        I2C0_LCD_SendData(*str++);
}

void I2C1_LCD_Print(const char *str)
{
    while(*str)
        I2C1_LCD_SendData(*str++);
}

void I2C0_LCD_SetCursor(uint8_t row, uint8_t col)
{
    uint8_t address = (row == 0) ? (0x80 + col) : (0xC0 + col);
    I2C0_LCD_SendCommand(address);
}

void I2C1_LCD_SetCursor(uint8_t row, uint8_t col)
{
    uint8_t address = (row == 0) ? (0x80 + col) : (0xC0 + col);
    I2C1_LCD_SendCommand(address);
}