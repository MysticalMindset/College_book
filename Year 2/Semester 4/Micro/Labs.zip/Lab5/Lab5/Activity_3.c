#include "lcd.h"
#include "delayMs.h"
#include "Activity_3.h"

void Activity3(void)
{
    I2C1_Init();
    I2C1_LCD_Init();
    I2C1_LCD_SetCursor(0, 0);
    I2C1_LCD_Print("  I2C1 Active!  ");
    I2C1_LCD_SetCursor(1, 0);
    I2C1_LCD_Print(" Humber College ");
    while(1)
    {
    }
}