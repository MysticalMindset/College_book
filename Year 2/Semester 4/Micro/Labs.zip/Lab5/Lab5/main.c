#include <stdio.h>
#include "RTE_Components.h"
#include CMSIS_device_header
#include "delayMs.h"
#include "Activity_1.h"
#include "Activity_2.h"
#include "Activity_3.h"
#include "lcd.h"

int main() {
    //Activity1();
    //Activity2();
    Activity3();
}
