//lcd.h
#ifndef LCD_H
#define LCD_H

#include <stdint.h>

void I2C0_Init(void);
void I2C0_WriteByte(uint8_t addr, uint8_t data);
void I2C1_Init(void);
void I2C1_WriteByte(uint8_t addr, uint8_t data);
void I2C0_LCD_ExpanderWrite(uint8_t data);
void I2C1_LCD_ExpanderWrite(uint8_t data);
void I2C0_LCD_PulseEnable(uint8_t data);
void I2C0_LCD_Write4Bits(uint8_t value);
void I2C0_LCD_SendCommand(uint8_t cmd);
void I2C0_LCD_SendData(uint8_t data);
void I2C0_LCD_Init(void);
void I2C0_LCD_Print(const char *str);
void I2C0_LCD_SetCursor(uint8_t row, uint8_t col);
void I2C1_LCD_PulseEnable(uint8_t data);
void I2C1_LCD_Write4Bits(uint8_t value);
void I2C1_LCD_SendCommand(uint8_t cmd);
void I2C1_LCD_SendData(uint8_t data);
void I2C1_LCD_Init(void);
void I2C1_LCD_Print(const char *str);
void I2C1_LCD_SetCursor(uint8_t row, uint8_t col);

#endif