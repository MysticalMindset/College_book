#include <stdio.h>
#include "TM4C123GH6PM.h"
#include "delayMs.h"
#include "Activity_1.h"
#include "lcd.h"

void Activity1(void){
    I2C0_Init();
    I2C0_LCD_Init();

    /* --- Line 1: Original position (row 0, col 0) --- */
    I2C0_LCD_SendCommand(0x80);          // DDRAM address 0x00 = row 1, col 1
    I2C0_LCD_Print("Hello Tiva");

    /* --- Line 2, Column 5 --- */
    /* Row 2 base DDRAM address = 0x40                  */
    /* Column 5 means offset 4 (0-indexed)              */
    /* So DDRAM address = 0x40 + 0x04 = 0x44            */
    /* Set DDRAM address command = 0x80 | 0x44 = 0xC4   */
    I2C0_LCD_SendCommand(0xC4);
    I2C0_LCD_Print("Hello Tiva");

    while(1)
    {
    }
}
