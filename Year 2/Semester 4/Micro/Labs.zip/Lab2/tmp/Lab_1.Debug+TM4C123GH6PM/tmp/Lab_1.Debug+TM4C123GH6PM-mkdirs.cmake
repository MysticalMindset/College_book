# Distributed under the OSI-approved BSD 3-Clause License.  See accompanying
# file Copyright.txt or https://cmake.org/licensing for details.

cmake_minimum_required(VERSION ${CMAKE_VERSION}) # this file comes with cmake

# If CMAKE_DISABLE_SOURCE_CHANGES is set to true and the source directory is an
# existing directory in our source tree, calling file(MAKE_DIRECTORY) on it
# would cause a fatal error, even though it would be a no-op.
if(NOT EXISTS "C:/Users/Murl0/Documents/Workzone/College_book/Year 2/Semester 4/Micro/Lab2/tmp/Lab_1.Debug+TM4C123GH6PM")
  file(MAKE_DIRECTORY "C:/Users/Murl0/Documents/Workzone/College_book/Year 2/Semester 4/Micro/Lab2/tmp/Lab_1.Debug+TM4C123GH6PM")
endif()
file(MAKE_DIRECTORY
  "C:/Users/Murl0/Documents/Workzone/College_book/Year 2/Semester 4/Micro/Lab2/tmp/1"
  "C:/Users/Murl0/Documents/Workzone/College_book/Year 2/Semester 4/Micro/Lab2/tmp/Lab_1.Debug+TM4C123GH6PM"
  "C:/Users/Murl0/Documents/Workzone/College_book/Year 2/Semester 4/Micro/Lab2/tmp/Lab_1.Debug+TM4C123GH6PM/tmp"
  "C:/Users/Murl0/Documents/Workzone/College_book/Year 2/Semester 4/Micro/Lab2/tmp/Lab_1.Debug+TM4C123GH6PM/src/Lab_1.Debug+TM4C123GH6PM-stamp"
  "C:/Users/Murl0/Documents/Workzone/College_book/Year 2/Semester 4/Micro/Lab2/tmp/Lab_1.Debug+TM4C123GH6PM/src"
  "C:/Users/Murl0/Documents/Workzone/College_book/Year 2/Semester 4/Micro/Lab2/tmp/Lab_1.Debug+TM4C123GH6PM/src/Lab_1.Debug+TM4C123GH6PM-stamp"
)

set(configSubDirs )
foreach(subDir IN LISTS configSubDirs)
    file(MAKE_DIRECTORY "C:/Users/Murl0/Documents/Workzone/College_book/Year 2/Semester 4/Micro/Lab2/tmp/Lab_1.Debug+TM4C123GH6PM/src/Lab_1.Debug+TM4C123GH6PM-stamp/${subDir}")
endforeach()
if(cfgdir)
  file(MAKE_DIRECTORY "C:/Users/Murl0/Documents/Workzone/College_book/Year 2/Semester 4/Micro/Lab2/tmp/Lab_1.Debug+TM4C123GH6PM/src/Lab_1.Debug+TM4C123GH6PM-stamp${cfgdir}") # cfgdir has leading slash
endif()
